<?php

defined( 'ABSPATH' ) || exit;

class Hostinger_Deactivator {
	public static function deactivate(): void {
		// Silence is golden
	}
}
